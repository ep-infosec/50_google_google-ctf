<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="base_out_atlas" tilewidth="32" tileheight="32" tilecount="2048" columns="32">
 <image source="base_out_atlas.png" width="1024" height="2048"/>
 <tile id="0">
  <objectgroup draworder="index" id="2">
   <object id="7" x="32" y="15">
    <polygon points="0,-3 -10,5 -15,17 -7,17 0,6"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="12" width="32" height="9"/>
  </objectgroup>
 </tile>
 <tile id="2">
  <objectgroup draworder="index" id="2">
   <object id="2" x="9" y="32">
    <polygon points="10,0 2,-12 -9,-20 -9,-11 0,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="3">
  <objectgroup draworder="index" id="2">
   <object id="2" x="0" y="12" width="8" height="9"/>
   <object id="4" x="25" y="0">
    <polygon points="0,0 -11,21 -17,21 -17,12 -8,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="4">
  <objectgroup draworder="index" id="2">
   <object id="2" x="25" y="12" width="7" height="9"/>
   <object id="4" x="16" y="0">
    <polygon points="3,0 9,12 9,21 -7,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="5">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="15">
    <polygon points="0,-3 -10,5 -15,17 -7,17 0,6"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="6">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="12" width="32" height="9"/>
  </objectgroup>
 </tile>
 <tile id="7">
  <objectgroup draworder="index" id="2">
   <object id="1" x="9" y="32">
    <polygon points="10,0 2,-12 -9,-20 -9,-11 0,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="8">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="12" width="8" height="9"/>
   <object id="2" x="25" y="0">
    <polygon points="0,0 -11,21 -17,21 -17,12 -8,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="9">
  <objectgroup draworder="index" id="2">
   <object id="2" x="25" y="12" width="7" height="9"/>
   <object id="3" x="16" y="0">
    <polygon points="3,0 9,12 9,21 -7,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="10">
  <objectgroup draworder="index" id="2">
   <object id="1" x="9" y="0" width="10" height="32"/>
  </objectgroup>
 </tile>
 <tile id="11">
  <objectgroup draworder="index" id="2">
   <object id="1" x="25" y="32">
    <polygon points="0,0 -8,0 -13,-22 -8,-32 0,-32"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="32">
  <objectgroup draworder="index" id="2">
   <object id="2" x="25" y="32">
    <polygon points="0,0 -8,0 -13,-22 -8,-32 0,-32"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="34">
  <objectgroup draworder="index" id="2">
   <object id="2" x="9" y="0" width="10" height="32"/>
  </objectgroup>
 </tile>
 <tile id="35">
  <objectgroup draworder="index" id="2">
   <object id="4" x="0" y="8">
    <polygon points="0,0 14,5 25,24 0,24"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="36">
  <objectgroup draworder="index" id="2">
   <object id="3" x="9" y="32">
    <polygon points="0,0 11,-18 23,-24 23,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="37">
  <objectgroup draworder="index" id="2">
   <object id="1" x="25" y="32">
    <polygon points="0,0 -8,0 -13,-22 -8,-32 0,-32"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="38">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="39">
  <objectgroup draworder="index" id="2">
   <object id="2" x="9" y="0" width="10" height="32"/>
  </objectgroup>
 </tile>
 <tile id="40">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="8">
    <polygon points="0,0 14,5 25,24 0,24"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="41">
  <objectgroup draworder="index" id="2">
   <object id="1" x="9" y="32">
    <polygon points="0,0 11,-18 23,-24 23,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="42">
  <objectgroup draworder="index" id="2">
   <object id="1" x="9" y="8">
    <polygon points="0,0 0,-8 10,-8 6,0"/>
   </object>
   <object id="2" x="0" y="8">
    <polygon points="0,0 15,0 12,24 0,24"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="43">
  <objectgroup draworder="index" id="2">
   <object id="1" x="17" y="0" width="8" height="8"/>
   <object id="2" x="17" y="8">
    <polygon points="0,0 15,0 15,24 3,24"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="64">
  <objectgroup draworder="index" id="2">
   <object id="3" x="17" y="0" width="8" height="8"/>
   <object id="5" x="17" y="8">
    <polygon points="0,0 15,0 15,24 3,24"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="65">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="8" width="32" height="24"/>
  </objectgroup>
 </tile>
 <tile id="66">
  <objectgroup draworder="index" id="2">
   <object id="3" x="9" y="8">
    <polygon points="0,0 0,-8 10,-8 6,0"/>
   </object>
   <object id="4" x="0" y="8">
    <polygon points="0,0 15,0 12,24 0,24"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="67">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="25" height="32"/>
  </objectgroup>
 </tile>
 <tile id="68">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="0" width="22" height="32"/>
  </objectgroup>
 </tile>
 <tile id="69">
  <objectgroup draworder="index" id="2">
   <object id="3" x="17" y="0" width="8" height="8"/>
   <object id="4" x="17" y="8">
    <polygon points="0,0 15,0 15,24 3,24"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="70">
  <objectgroup draworder="index" id="2">
   <object id="3" x="0" y="8" width="32" height="24"/>
  </objectgroup>
 </tile>
 <tile id="71">
  <objectgroup draworder="index" id="2">
   <object id="3" x="9" y="8">
    <polygon points="0,0 0,-8 10,-8 6,0"/>
   </object>
   <object id="4" x="0" y="8">
    <polygon points="0,0 15,0 12,24 0,24"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="72">
  <objectgroup draworder="index" id="2">
   <object id="2" x="0" y="0" width="25" height="32"/>
  </objectgroup>
 </tile>
 <tile id="73">
  <objectgroup draworder="index" id="2">
   <object id="2" x="10" y="0" width="22" height="32"/>
  </objectgroup>
 </tile>
 <tile id="74">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="12" height="32"/>
  </objectgroup>
 </tile>
 <tile id="75">
  <objectgroup draworder="index" id="2">
   <object id="1" x="20" y="0" width="12" height="32"/>
  </objectgroup>
 </tile>
 <tile id="88">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="14">
    <polygon points="0,0 -12,5 -19,18 0,18"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="89">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="14" width="32" height="18"/>
  </objectgroup>
 </tile>
 <tile id="90">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="14">
    <polygon points="0,0 12,5 19,18 0,18"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="91">
  <objectgroup draworder="index" id="2">
   <object id="1" x="9" y="32">
    <polygon points="0,0 23,-24 23,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="92">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="8" width="32" height="24"/>
  </objectgroup>
 </tile>
 <tile id="93">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="8">
    <polygon points="0,0 4,0 18,11 23,24 0,24"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="96">
  <objectgroup draworder="index" id="2">
   <object id="1" x="20" y="0" width="12" height="32"/>
  </objectgroup>
 </tile>
 <tile id="97">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="98">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="12" height="32"/>
  </objectgroup>
 </tile>
 <tile id="99">
  <objectgroup draworder="index" id="2">
   <object id="5" x="0" y="0" width="25" height="10"/>
   <object id="6" x="15" y="10">
    <polygon points="0,0 2,22 10,22 10,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="100">
  <objectgroup draworder="index" id="2">
   <object id="1" x="9" y="10" width="10" height="22"/>
   <object id="2" x="9" y="0" width="23" height="10"/>
  </objectgroup>
 </tile>
 <tile id="101">
  <objectgroup draworder="index" id="2">
   <object id="1" x="20" y="0" width="12" height="32"/>
  </objectgroup>
 </tile>
 <tile id="102">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="103">
  <objectgroup draworder="index" id="2">
   <object id="2" x="0" y="0" width="12" height="32"/>
  </objectgroup>
 </tile>
 <tile id="104">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="25" height="10"/>
   <object id="2" x="15" y="10">
    <polygon points="0,0 2,22 10,22 10,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="105">
  <objectgroup draworder="index" id="2">
   <object id="3" x="9" y="10" width="10" height="22"/>
   <object id="4" x="9" y="0" width="23" height="10"/>
  </objectgroup>
 </tile>
 <tile id="106">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="107">
  <objectgroup draworder="index" id="2">
   <object id="1" x="20" y="0" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="120">
  <objectgroup draworder="index" id="2">
   <object id="1" x="13" y="0" width="19" height="32"/>
  </objectgroup>
 </tile>
 <tile id="122">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="19" height="32"/>
  </objectgroup>
 </tile>
 <tile id="123">
  <objectgroup draworder="index" id="2">
   <object id="1" x="9" y="0" width="23" height="32"/>
  </objectgroup>
 </tile>
 <tile id="125">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="23" height="32"/>
  </objectgroup>
 </tile>
 <tile id="128">
  <objectgroup draworder="index" id="2">
   <object id="1" x="20" y="0" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="129">
  <objectgroup draworder="index" id="3">
   <object id="2" x="0" y="0" width="32" height="10"/>
  </objectgroup>
 </tile>
 <tile id="130">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="133">
  <objectgroup draworder="index" id="2">
   <object id="1" x="20" y="0" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="134">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="10"/>
  </objectgroup>
 </tile>
 <tile id="135">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="12" height="10"/>
  </objectgroup>
 </tile>
 <tile id="152">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="18">
    <polygon points="0,0 -12,-5 -19,-18 0,-18"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="153">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="18"/>
  </objectgroup>
 </tile>
 <tile id="154">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="18">
    <polygon points="0,0 12,-5 19,-18 0,-18"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="155">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="20">
    <polygon points="0,0 -23,-20 0,-20"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="156">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="20"/>
  </objectgroup>
 </tile>
 <tile id="157">
  <objectgroup draworder="index" id="2">
   <object id="1" x="23" y="0">
    <polygon points="0,0 -15,21 -23,20 -23,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="161">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="8" width="32" height="11"/>
   <object id="2" x="0" y="19" width="8" height="13"/>
  </objectgroup>
 </tile>
 <tile id="162">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="8" width="32" height="11"/>
   <object id="2" x="24" y="19" width="8" height="13"/>
  </objectgroup>
 </tile>
 <tile id="163">
  <objectgroup draworder="index" id="2">
   <object id="1" x="20" y="8" width="12" height="23.9375"/>
   <object id="2" x="20" y="0" width="5" height="8"/>
  </objectgroup>
 </tile>
 <tile id="164">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="8" width="32" height="24"/>
  </objectgroup>
 </tile>
 <tile id="165">
  <objectgroup draworder="index" id="2">
   <object id="1" x="1" y="32">
    <polygon points="-1,0 21,-25 15,-26 -1,-23"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="166">
  <objectgroup draworder="index" id="2">
   <object id="1" x="12" y="10">
    <polygon points="0,0 20,22 20,-2 9,-4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="167">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="8" width="32" height="24"/>
  </objectgroup>
 </tile>
 <tile id="168">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="8" width="12" height="24"/>
   <object id="2" x="9" y="8">
    <polygon points="0,0 0,-8 7,-8 3,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="175" probability="0.05"/>
 <tile id="176" probability="0.1"/>
 <tile id="177" probability="0.1"/>
 <tile id="178" probability="0.05"/>
 <tile id="179" probability="0.1"/>
 <tile id="180" probability="0.1"/>
 <tile id="181" probability="0.05"/>
 <tile id="182" probability="0.1"/>
 <tile id="183" probability="0.1"/>
 <tile id="193">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="8" height="32"/>
  </objectgroup>
 </tile>
 <tile id="194">
  <objectgroup draworder="index" id="2">
   <object id="1" x="24" y="0" width="8" height="32"/>
  </objectgroup>
 </tile>
 <tile id="195">
  <objectgroup draworder="index" id="2">
   <object id="1" x="20" y="0" width="12" height="32"/>
  </objectgroup>
 </tile>
 <tile id="196">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0">
    <polygon points="0,0 32,0 0,32"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="197">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="31">
    <polygon points="0,-19 -11,-19 -32,1 0,1"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="198">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="31">
    <polygon points="-18,-19 -32,-19 -32,1 0,1"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="199">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="32">
    <polygon points="0,0 -32,-32 0,-32"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="200">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="12" height="32"/>
  </objectgroup>
 </tile>
 <tile id="207">
  <objectgroup draworder="index" id="2">
   <object id="1" x="4" y="8" width="24" height="19"/>
  </objectgroup>
 </tile>
 <tile id="208">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="14">
    <polygon points="0,-14 -32,-14 -32,18 -13,18 0,4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="209">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="14">
    <polygon points="0,-14 32,-14 32,18 13,18 0,4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="225">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="8" height="10"/>
  </objectgroup>
 </tile>
 <tile id="226">
  <objectgroup draworder="index" id="2">
   <object id="1" x="24" y="0" width="8" height="9"/>
  </objectgroup>
 </tile>
 <tile id="227">
  <objectgroup draworder="index" id="2">
   <object id="1" x="20" y="0">
    <polygon points="0,0 3,5 10,5 12,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="228">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="31">
    <polygon points="0,-31 -32,1 0,1"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="231">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="31">
    <polygon points="-32,-31 -32,1 0,1"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="232">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="1">
    <polygon points="0,0 3,4 8,4 10,-1 0,-1"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="234">
  <objectgroup draworder="index" id="2">
   <object id="1" x="1" y="25">
    <polygon points="0,7 5,-25 25,-25 31,0 16,7"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="239">
  <objectgroup draworder="index" id="2">
   <object id="1" x="8" y="9" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="240">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="18">
    <polygon points="0,14 -32,14 -32,-18 -13,-18 0,-4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="241">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="18">
    <polygon points="0,14 32,14 32,-18 13,-18 0,-4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="256">
  <objectgroup draworder="index" id="2">
   <object id="1" x="3" y="0" width="26" height="30"/>
  </objectgroup>
 </tile>
 <tile id="257">
  <objectgroup draworder="index" id="2">
   <object id="1" x="3" y="0" width="26" height="30"/>
  </objectgroup>
 </tile>
 <tile id="258">
  <objectgroup draworder="index" id="2">
   <object id="1" x="3" y="0" width="26" height="30"/>
  </objectgroup>
 </tile>
 <tile id="259">
  <objectgroup draworder="index" id="2">
   <object id="1" x="24" y="4">
    <polygon points="0,0 1,6 8,6 8,-4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="260">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="10"/>
  </objectgroup>
 </tile>
 <tile id="261">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="10"/>
  </objectgroup>
 </tile>
 <tile id="262">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="10"/>
  </objectgroup>
 </tile>
 <tile id="263">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="10"/>
  </objectgroup>
 </tile>
 <tile id="264">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="10">
    <polygon points="0,0 7,0 9,-4 0,-10"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="268">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="14">
    <polygon points="0,0 -12,5 -19,18 0,18"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="269">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="14" width="32" height="18"/>
  </objectgroup>
 </tile>
 <tile id="270">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="14">
    <polygon points="0,0 12,5 19,18 0,18"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="271">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="14">
    <polygon points="0,0 -12,5 -19,18 0,18"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="272">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="14" width="32" height="18"/>
  </objectgroup>
 </tile>
 <tile id="273">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="14">
    <polygon points="0,0 12,5 19,18 0,18"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="297">
  <objectgroup draworder="index" id="2">
   <object id="1" x="8" y="9" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="298">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="14">
    <polygon points="0,-14 -32,-14 -32,18 -13,18 0,4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="299">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="14">
    <polygon points="0,-14 32,-14 32,18 13,18 0,4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="300">
  <objectgroup draworder="index" id="2">
   <object id="1" x="13" y="0" width="19" height="32"/>
  </objectgroup>
 </tile>
 <tile id="302">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="19" height="32"/>
  </objectgroup>
 </tile>
 <tile id="303">
  <objectgroup draworder="index" id="2">
   <object id="1" x="13" y="0" width="19" height="32"/>
  </objectgroup>
 </tile>
 <tile id="305">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="19" height="32"/>
  </objectgroup>
 </tile>
 <tile id="326">
  <objectgroup draworder="index" id="2">
   <object id="1" x="7" y="0" width="18" height="24"/>
  </objectgroup>
 </tile>
 <tile id="329">
  <objectgroup draworder="index" id="2">
   <object id="1" x="8" y="9" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="330">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="18">
    <polygon points="0,14 -32,14 -32,-18 -13,-18 0,-4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="331">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="18">
    <polygon points="0,14 32,14 32,-18 13,-18 0,-4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="332">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="18">
    <polygon points="0,0 -12,-5 -19,-18 0,-18"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="333">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="18"/>
  </objectgroup>
 </tile>
 <tile id="334">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="18">
    <polygon points="0,0 12,-5 19,-18 0,-18"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="335">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="18">
    <polygon points="0,0 -12,-5 -19,-18 0,-18"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="336">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="18"/>
  </objectgroup>
 </tile>
 <tile id="337">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="18">
    <polygon points="0,0 12,-5 19,-18 0,-18"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="344">
  <objectgroup draworder="index" id="2">
   <object id="1" x="16" y="0" width="16" height="32"/>
  </objectgroup>
 </tile>
 <tile id="346">
  <objectgroup draworder="index" id="4">
   <object id="3" x="0" y="0" width="16" height="32"/>
  </objectgroup>
 </tile>
 <tile id="349">
  <objectgroup draworder="index" id="2">
   <object id="1" x="8" y="4" width="24" height="24"/>
  </objectgroup>
 </tile>
 <tile id="350">
  <objectgroup draworder="index" id="2">
   <object id="1" x="8" y="4" width="24" height="24"/>
  </objectgroup>
 </tile>
 <tile id="351">
  <objectgroup draworder="index" id="2">
   <object id="1" x="8" y="4" width="24" height="24"/>
  </objectgroup>
 </tile>
 <tile id="361">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="14">
    <polygon points="0,0 -12,5 -19,18 0,18"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="362">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="14" width="32" height="18"/>
  </objectgroup>
 </tile>
 <tile id="363">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="14">
    <polygon points="0,0 12,5 19,18 0,18"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="373">
  <objectgroup draworder="index" id="2">
   <object id="1" x="8" y="8" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="374">
  <objectgroup draworder="index" id="2">
   <object id="3" x="32" y="14">
    <polygon points="0,-14 -32,-14 -32,18 -13,18 0,4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="375">
  <objectgroup draworder="index" id="2">
   <object id="3" x="0" y="14">
    <polygon points="0,-14 32,-14 32,18 13,18 0,4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="376" probability="0.01"/>
 <tile id="377" probability="0.01"/>
 <tile id="378" probability="0.01"/>
 <tile id="381">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="4" width="24" height="24"/>
  </objectgroup>
 </tile>
 <tile id="382">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="4" width="24" height="24"/>
  </objectgroup>
 </tile>
 <tile id="383">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="4" width="24" height="24"/>
  </objectgroup>
 </tile>
 <tile id="393">
  <objectgroup draworder="index" id="2">
   <object id="1" x="13" y="0" width="19" height="32"/>
  </objectgroup>
 </tile>
 <tile id="394">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="395">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="19" height="32"/>
  </objectgroup>
 </tile>
 <tile id="397">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="399">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="23">
    <polygon points="0,0 5,-21 18,-22 29,-16 32,-2 24,9 12,8"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="400">
  <objectgroup draworder="index" id="2">
   <object id="1" x="4" y="2" width="15" height="6"/>
   <object id="2" x="13" y="12" width="16" height="14"/>
  </objectgroup>
 </tile>
 <tile id="401">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="10" width="32" height="22"/>
  </objectgroup>
 </tile>
 <tile id="405">
  <objectgroup draworder="index" id="2">
   <object id="1" x="8" y="8" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="406">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="18">
    <polygon points="0,14 -32,14 -32,-18 -13,-18 0,-4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="407">
  <objectgroup draworder="index" id="2">
   <object id="3" x="0" y="18">
    <polygon points="0,14 32,14 32,-18 13,-18 0,-4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="425">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="18">
    <polygon points="0,0 -12,-5 -19,-18 0,-18"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="426">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="18"/>
  </objectgroup>
 </tile>
 <tile id="427">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="18">
    <polygon points="0,0 12,-5 19,-18 0,-18"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="429">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="433">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="434">
  <objectgroup draworder="index" id="2">
   <object id="1" x="1" y="8" width="26" height="21"/>
   <object id="2" x="16" y="0" width="16" height="8"/>
  </objectgroup>
 </tile>
 <tile id="435">
  <properties>
   <property name="frameset" value="fireplace_on"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="27"/>
  </objectgroup>
 </tile>
 <tile id="437">
  <objectgroup draworder="index" id="2">
   <object id="2" x="32" y="14">
    <polygon points="0,0 -12,5 -19,18 0,18"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="438">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="14" width="32" height="18"/>
  </objectgroup>
 </tile>
 <tile id="439">
  <objectgroup draworder="index" id="2">
   <object id="2" x="0" y="14">
    <polygon points="0,0 12,5 19,18 0,18"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="457" probability="0.015">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="458" probability="0.015">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="459" probability="0.015">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="461">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="463">
  <objectgroup draworder="index" id="2">
   <object id="1" x="6" y="9">
    <polygon points="0,0 1,16 7,19 13,19 17,16 20,5 20,0 13,-4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="464">
  <objectgroup draworder="index" id="2">
   <object id="1" x="8" y="32">
    <polygon points="0,0 -2,-7 5,-11 11,-11 18,-7 18,-1 16,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="465">
  <objectgroup draworder="index" id="2">
   <object id="1" x="8" y="32">
    <polygon points="0,0 -2,-7 5,-11 11,-11 18,-7 18,-1 16,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="466">
  <objectgroup draworder="index" id="2">
   <object id="1" x="2" y="32">
    <polygon points="0,0 3,-18 10,-22 18,-22 26,-16 28,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="467">
  <objectgroup draworder="index" id="2">
   <object id="1" x="5" y="32">
    <polygon points="0,0 4,-5 18,-5 22,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="468">
  <objectgroup draworder="index" id="2">
   <object id="2" x="0" y="13.0427" width="32" height="18.9573"/>
  </objectgroup>
 </tile>
 <tile id="469">
  <objectgroup draworder="index" id="2">
   <object id="1" x="13" y="0" width="19" height="32"/>
  </objectgroup>
 </tile>
 <tile id="470">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="471">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="19" height="32"/>
  </objectgroup>
 </tile>
 <tile id="493">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="495">
  <objectgroup draworder="index" id="2">
   <object id="1" x="6" y="9">
    <polygon points="0,0 1,16 7,19 13,19 17,16 20,5 20,0 13,-4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="496">
  <objectgroup draworder="index" id="2">
   <object id="1" x="7" y="0">
    <polygon points="0,0 2,10 15,11 18,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="497">
  <objectgroup draworder="index" id="2">
   <object id="1" x="7" y="0">
    <polygon points="0,0 2,10 15,11 18,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="498">
  <objectgroup draworder="index" id="2">
   <object id="1" x="3" y="0">
    <polygon points="0,0 1,9 9,14 16,14 24,11 26,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="499">
  <objectgroup draworder="index" id="2">
   <object id="1" x="3" y="24">
    <polygon points="0,0 10,7 17,7 26,0 27,-15 25,-24 1,-24"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="500">
  <properties>
   <property name="frameset" value="fireplace_off"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="27"/>
  </objectgroup>
 </tile>
 <tile id="501">
  <objectgroup draworder="index" id="2">
   <object id="2" x="32" y="18">
    <polygon points="0,0 -12,-5 -19,-18 0,-18"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="502">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="18"/>
  </objectgroup>
 </tile>
 <tile id="503">
  <objectgroup draworder="index" id="2">
   <object id="2" x="0" y="18">
    <polygon points="0,0 12,-5 19,-18 0,-18"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="525">
  <objectgroup draworder="index" id="2">
   <object id="1" x="20" y="28" width="12" height="4"/>
   <object id="2" x="19" y="0" width="13" height="2"/>
  </objectgroup>
 </tile>
 <tile id="526">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="2"/>
   <object id="2" x="0" y="28" width="32" height="4"/>
  </objectgroup>
 </tile>
 <tile id="527">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="17" height="3"/>
   <object id="2" x="0" y="28" width="20" height="4"/>
  </objectgroup>
 </tile>
 <tile id="531">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="2">
    <polygon points="0,0 -29,15 -32,30 0,30"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="532">
  <objectgroup draworder="index" id="2">
   <object id="1" x="14" y="32">
    <polygon points="0,0 1,-20 -5,-29 -14,-30 -14,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="533" probability="0.015"/>
 <tile id="534" probability="0.015"/>
 <tile id="535" probability="0.015"/>
 <tile id="557">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="6" width="11" height="7"/>
   <object id="2" x="10" y="0" width="14" height="6"/>
   <object id="3" x="5" y="2" width="5" height="4"/>
  </objectgroup>
 </tile>
 <tile id="559">
  <objectgroup draworder="index" id="2">
   <object id="1" x="8" y="0" width="15" height="3"/>
   <object id="2" x="21" y="8" width="11" height="5"/>
   <object id="3" x="17" y="3" width="12" height="5"/>
  </objectgroup>
 </tile>
 <tile id="563">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0">
    <polygon points="0,0 1,11 27,30 32,30 32,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="564">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="30">
    <polygon points="0,0 11,-6 14,-30 0,-30"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="565">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="566">
  <properties>
   <property name="frameset" value="closed"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="3" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="589">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="16" width="5" height="16"/>
   <object id="2" x="27" y="16" width="5" height="16"/>
  </objectgroup>
 </tile>
 <tile id="590">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="5" height="32"/>
   <object id="2" x="27" y="0" width="5" height="32"/>
  </objectgroup>
 </tile>
 <tile id="598">
  <properties>
   <property name="frameset" value="open"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="2" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="606">
  <objectgroup draworder="index" id="2">
   <object id="1" x="31" y="0" width="1" height="32"/>
  </objectgroup>
 </tile>
 <tile id="607">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="1" height="32"/>
  </objectgroup>
 </tile>
 <tile id="621">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="5" height="32"/>
   <object id="2" x="27" y="0" width="5" height="32"/>
  </objectgroup>
 </tile>
 <tile id="622">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="5" height="32"/>
   <object id="3" x="27" y="0" width="5" height="32"/>
  </objectgroup>
 </tile>
 <tile id="638">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="31" width="32" height="1"/>
  </objectgroup>
 </tile>
 <tile id="639">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="1"/>
  </objectgroup>
 </tile>
 <tile id="653">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="5" height="16"/>
   <object id="2" x="27" y="0" width="5" height="16"/>
  </objectgroup>
 </tile>
 <tile id="654">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="4" height="16"/>
   <object id="2" x="28" y="0" width="4" height="16"/>
  </objectgroup>
 </tile>
 <tile id="656">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="2" height="32"/>
   <object id="2" x="30" y="0" width="2" height="32"/>
  </objectgroup>
 </tile>
 <tile id="657">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="2" height="32"/>
  </objectgroup>
 </tile>
 <tile id="658">
  <objectgroup draworder="index" id="2">
   <object id="1" x="30" y="0" width="2" height="32"/>
  </objectgroup>
 </tile>
 <tile id="666">
  <objectgroup draworder="index" id="2">
   <object id="1" x="8" y="0" width="16" height="39"/>
  </objectgroup>
 </tile>
 <tile id="669">
  <objectgroup draworder="index" id="2">
   <object id="2" x="8" y="0" width="16" height="39"/>
  </objectgroup>
 </tile>
 <tile id="671">
  <objectgroup draworder="index" id="2">
   <object id="1" x="15.5" y="0" width="1" height="32"/>
  </objectgroup>
 </tile>
 <tile id="672">
  <properties>
   <property name="frameset" value="grate_door_upper_closed"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="704">
  <properties>
   <property name="frameset" value="grate_door_lower_closed"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="24"/>
  </objectgroup>
 </tile>
 <tile id="733">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="15.5" width="32" height="1"/>
  </objectgroup>
 </tile>
 <tile id="894">
  <objectgroup draworder="index" id="3">
   <object id="2" x="0" y="0" width="1" height="32"/>
   <object id="3" x="1" y="0" width="31" height="1"/>
  </objectgroup>
 </tile>
 <tile id="895">
  <objectgroup draworder="index" id="2">
   <object id="1" x="31" y="0" width="1" height="32"/>
   <object id="2" x="0" y="0" width="31" height="1"/>
  </objectgroup>
 </tile>
 <tile id="926">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="1" height="32"/>
   <object id="2" x="1" y="31" width="31" height="1"/>
  </objectgroup>
 </tile>
 <tile id="927">
  <objectgroup draworder="index" id="2">
   <object id="1" x="31" y="0" width="1" height="32"/>
   <object id="2" x="0" y="31" width="31" height="1"/>
  </objectgroup>
 </tile>
 <tile id="1024">
  <objectgroup draworder="index" id="2">
   <object id="2" x="21" y="32">
    <polygon points="0,0 11,-14 11,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1025">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="18">
    <polygon points="0,0 -12,-3 -32,0 -32,14 0,14"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1026">
  <objectgroup draworder="index" id="2">
   <object id="1" x="13" y="32">
    <polygon points="0,0 -10,-14 -13,-14 -13,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1027">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="18">
    <polygon points="0,0 21,-18 32,-18 32,14 0,14"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1028">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0">
    <polygon points="0,0 13,0 32,18 32,32 0,32"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1035" probability="0.009">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1036">
  <objectgroup draworder="index" id="2">
   <object id="1" x="14" y="22" width="18" height="10"/>
  </objectgroup>
 </tile>
 <tile id="1037">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="21" width="13" height="11"/>
  </objectgroup>
 </tile>
 <tile id="1038" probability="0.01"/>
 <tile id="1056">
  <objectgroup draworder="index" id="2">
   <object id="1" x="21" y="0">
    <polygon points="0,0 -6,7 -6,15 0,32 11,32 11,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1057">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1058">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0">
    <polygon points="0,0 0,32 13,32 16,28 16,16 13,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1059">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1060">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1067" probability="0.005">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1068">
  <objectgroup draworder="index" id="2">
   <object id="1" x="21" y="0" width="11" height="12"/>
  </objectgroup>
 </tile>
 <tile id="1069">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="12" height="11"/>
  </objectgroup>
 </tile>
 <tile id="1070" probability="0.017"/>
 <tile id="1088">
  <objectgroup draworder="index" id="2">
   <object id="1" x="20" y="0">
    <polygon points="1,0 -2,32 12,32 12,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1090">
  <objectgroup draworder="index" id="2">
   <object id="1" x="11" y="32">
    <polygon points="0,0 2,-32 -11,-32 -11,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1091">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1092">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1099">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="19" height="32"/>
   <object id="2" x="19" y="0" width="13" height="19"/>
  </objectgroup>
 </tile>
 <tile id="1100">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="18"/>
  </objectgroup>
 </tile>
 <tile id="1101">
  <objectgroup draworder="index" id="2">
   <object id="1" x="13" y="0" width="19" height="32"/>
   <object id="2" x="0" y="0" width="13" height="21"/>
  </objectgroup>
 </tile>
 <tile id="1120">
  <objectgroup draworder="index" id="2">
   <object id="1" x="18" y="0">
    <polygon points="0,0 -3,11 2,32 14,32 14,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1122">
  <objectgroup draworder="index" id="2">
   <object id="1" x="10" y="32">
    <polygon points="0,0 6,-6 6,-16 1,-32 -10,-32 -10,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1123">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="10">
    <polygon points="21,22 32,22 32,-10 15,-10 15,0"/>
   </object>
   <object id="2" x="0" y="0" width="15" height="10"/>
  </objectgroup>
 </tile>
 <tile id="1124">
  <objectgroup draworder="index" id="2">
   <object id="1" x="13" y="32">
    <polygon points="0,0 1,-21 1,-32 -13,-32 -13,0"/>
   </object>
   <object id="2" x="14" y="0" width="18" height="10"/>
  </objectgroup>
 </tile>
 <tile id="1126" probability="0.03"/>
 <tile id="1131">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1133">
  <objectgroup draworder="index" id="2">
   <object id="1" x="14" y="0" width="18" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1152">
  <objectgroup draworder="index" id="2">
   <object id="1" x="20" y="0">
    <polygon points="0,0 -1,8 12,10 12,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1153">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="11">
    <polygon points="0,-1 14,0 32,-1 32,-11 0,-11"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1154">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="9">
    <polygon points="0,1 7,3 10,0 10,-9 0,-9"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1163">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="20" height="32"/>
   <object id="2" x="20" y="14" width="12" height="18"/>
  </objectgroup>
 </tile>
 <tile id="1164">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="18" width="32" height="14"/>
  </objectgroup>
 </tile>
 <tile id="1165">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="15" width="32" height="17"/>
   <object id="2" x="12" y="0" width="20" height="15"/>
  </objectgroup>
 </tile>
 <tile id="1180">
  <objectgroup draworder="index" id="2">
   <object id="1" x="13" y="0" width="19" height="4"/>
   <object id="2" x="4" y="4" width="12" height="3"/>
   <object id="3" x="1" y="7" width="8" height="2"/>
   <object id="5" x="15" y="29" width="17" height="3"/>
  </objectgroup>
 </tile>
 <tile id="1181">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="28" width="32" height="4"/>
   <object id="2" x="0" y="0" width="32" height="3"/>
  </objectgroup>
 </tile>
 <tile id="1182">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="17" height="4"/>
   <object id="2" x="17" y="4" width="10" height="2"/>
   <object id="3" x="24" y="6" width="8" height="3"/>
   <object id="4" x="0" y="29" width="17" height="3"/>
  </objectgroup>
 </tile>
 <tile id="1184">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1185">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1189" probability="0.01"/>
 <tile id="1190" probability="0.2"/>
 <tile id="1199">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="18" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1200">
  <objectgroup draworder="index" id="2">
   <object id="1" x="14" y="0" width="18" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1212">
  <objectgroup draworder="index" id="5">
   <object id="4" x="0" y="10" width="8" height="3"/>
   <object id="5" x="2" y="6" width="7" height="4"/>
   <object id="6" x="6" y="2" width="11" height="4"/>
   <object id="7" x="10" y="0" width="14" height="2"/>
  </objectgroup>
 </tile>
 <tile id="1214">
  <objectgroup draworder="index" id="2">
   <object id="1" x="9" y="0" width="13" height="3"/>
   <object id="2" x="17" y="3" width="11" height="3"/>
   <object id="4" x="21" y="6" width="9" height="3"/>
   <object id="5" x="24" y="9" width="8" height="4"/>
  </objectgroup>
 </tile>
 <tile id="1216">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="10">
    <polygon points="20,22 32,22 32,-10 20,-10"/>
   </object>
   <object id="2" x="0" y="0" width="20" height="10"/>
  </objectgroup>
 </tile>
 <tile id="1217">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="10">
    <polygon points="-17,16 -22,22 -32,22 -32,-10 -17,-10"/>
   </object>
   <object id="2" x="15" y="0" width="17" height="10"/>
  </objectgroup>
 </tile>
 <tile id="1218">
  <objectgroup draworder="index" id="2">
   <object id="1" x="20" y="8" width="12" height="23.9375"/>
   <object id="2" x="20" y="0" width="5" height="8"/>
  </objectgroup>
 </tile>
 <tile id="1219">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="8" width="32" height="24"/>
  </objectgroup>
 </tile>
 <tile id="1220">
  <objectgroup draworder="index" id="2">
   <object id="1" x="1" y="32">
    <polygon points="-1,0 21,-25 15,-26 -1,-23"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1221">
  <objectgroup draworder="index" id="2">
   <object id="1" x="12" y="10">
    <polygon points="0,0 20,22 20,-2 9,-4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1222">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="8" width="32" height="24"/>
  </objectgroup>
 </tile>
 <tile id="1223">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="8" width="12" height="24"/>
   <object id="2" x="9" y="8">
    <polygon points="0,0 0,-8 7,-8 3,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1231">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="18" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1232">
  <objectgroup draworder="index" id="2">
   <object id="1" x="14" y="0" width="18" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1250">
  <objectgroup draworder="index" id="2">
   <object id="1" x="20" y="0" width="12" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1251">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0">
    <polygon points="0,0 32,0 0,32"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1252">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="31">
    <polygon points="0,-19 -11,-19 -32,1 0,1"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1253">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="31">
    <polygon points="-18,-19 -32,-19 -32,1 0,1"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1254">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="32">
    <polygon points="0,0 -32,-32 0,-32"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1255">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="12" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1280">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="24" height="32"/>
   <object id="2" x="24" y="8" width="8" height="24"/>
  </objectgroup>
 </tile>
 <tile id="1281">
  <objectgroup draworder="index" id="2">
   <object id="1" x="9" y="0" width="23" height="32"/>
   <object id="2" x="0" y="8" width="9" height="24"/>
  </objectgroup>
 </tile>
 <tile id="1282">
  <objectgroup draworder="index" id="2">
   <object id="1" x="20" y="0">
    <polygon points="0,0 3,5 10,5 12,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1283">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="31">
    <polygon points="0,-31 -32,1 0,1"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1286">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="31">
    <polygon points="-32,-31 -32,1 0,1"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1287">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="1">
    <polygon points="0,0 3,4 8,4 10,-1 0,-1"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1308">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="28" width="32" height="4"/>
   <object id="2" x="27" y="0" width="5" height="28"/>
   <object id="3" x="0" y="0">
    <polygon points="0,0 0,2 5,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1310">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="6" height="28"/>
   <object id="2" x="0" y="28" width="32" height="4"/>
   <object id="3" x="32" y="0">
    <polygon points="0,0 0,2 -5,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1312">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="20" height="10"/>
   <object id="3" x="20" y="0" width="12" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1313">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="10">
    <polygon points="-17,16 -20,22 -32,22 -32,-10 -17,-10"/>
   </object>
   <object id="2" x="15" y="0" width="17" height="10"/>
  </objectgroup>
 </tile>
 <tile id="1314">
  <objectgroup draworder="index" id="2">
   <object id="1" x="24" y="4">
    <polygon points="0,0 1,6 8,6 8,-4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1315">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="10"/>
  </objectgroup>
 </tile>
 <tile id="1316">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="10"/>
  </objectgroup>
 </tile>
 <tile id="1317">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="10"/>
  </objectgroup>
 </tile>
 <tile id="1318">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="10"/>
  </objectgroup>
 </tile>
 <tile id="1319">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="10">
    <polygon points="0,0 7,0 9,-4 0,-10"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1372">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="2"/>
   <object id="2" x="27" y="2" width="5" height="30"/>
   <object id="3" x="0" y="32">
    <polygon points="0,0 5,0 0,-4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1374">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="2"/>
   <object id="2" x="0" y="2" width="5" height="30"/>
   <object id="3" x="32" y="32">
    <polygon points="0,0 -5,0 0,-4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1384">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="8" width="32" height="11"/>
   <object id="3" x="0" y="19" width="14" height="13"/>
  </objectgroup>
 </tile>
 <tile id="1385">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="8" width="32" height="11"/>
   <object id="2" x="18" y="19" width="14" height="13"/>
  </objectgroup>
 </tile>
 <tile id="1408">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="24" height="32"/>
   <object id="2" x="24" y="8" width="8" height="24"/>
  </objectgroup>
 </tile>
 <tile id="1409">
  <objectgroup draworder="index" id="2">
   <object id="1" x="9" y="0" width="23" height="32"/>
   <object id="2" x="0" y="8" width="9" height="24"/>
  </objectgroup>
 </tile>
 <tile id="1415">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="3" height="32"/>
   <object id="2" x="29" y="0" width="3" height="32"/>
   <object id="3" x="3" y="0" width="26" height="3"/>
  </objectgroup>
 </tile>
 <tile id="1416">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="14" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1417">
  <objectgroup draworder="index" id="2">
   <object id="1" x="18" y="0" width="14" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1440">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="20" height="10"/>
   <object id="2" x="20" y="0" width="12" height="32"/>
  </objectgroup>
 </tile>
 <tile id="1441">
  <objectgroup draworder="index" id="2">
   <object id="1" x="32" y="10">
    <polygon points="-17,16 -20,22 -32,22 -32,-10 -17,-10"/>
   </object>
   <object id="2" x="15" y="0" width="17" height="10"/>
  </objectgroup>
 </tile>
 <tile id="1447">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="3" height="10"/>
   <object id="2" x="29" y="0" width="3" height="10"/>
  </objectgroup>
 </tile>
 <tile id="1448">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="14" height="10"/>
  </objectgroup>
 </tile>
 <tile id="1449">
  <objectgroup draworder="index" id="2">
   <object id="1" x="18" y="0" width="14" height="10"/>
  </objectgroup>
 </tile>
 <tile id="2039">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <tile id="2047">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
 <wangsets>
  <wangset name="EdgeOnlySet" type="corner" tile="-1">
   <wangcolor name="Lava" color="#ff0000" tile="-1" probability="1"/>
   <wangcolor name="Grass" color="#00ff00" tile="-1" probability="1"/>
   <wangcolor name="Water" color="#0000ff" tile="-1" probability="1"/>
   <wangcolor name="DarkStone" color="#ff7700" tile="-1" probability="1"/>
   <wangcolor name="LightStone" color="#00e9ff" tile="-1" probability="1"/>
   <wangcolor name="Sand" color="#ff00d8" tile="-1" probability="1"/>
   <wangcolor name="YellowGrass" color="#ffff00" tile="-1" probability="1"/>
   <wangtile tileid="22" wangid="0,2,0,0,0,2,0,2"/>
   <wangtile tileid="23" wangid="0,2,0,2,0,0,0,2"/>
   <wangtile tileid="54" wangid="0,0,0,2,0,2,0,2"/>
   <wangtile tileid="55" wangid="0,2,0,2,0,2,0,0"/>
   <wangtile tileid="85" wangid="0,0,0,2,0,0,0,0"/>
   <wangtile tileid="86" wangid="0,0,0,2,0,2,0,0"/>
   <wangtile tileid="87" wangid="0,0,0,0,0,2,0,0"/>
   <wangtile tileid="117" wangid="0,2,0,2,0,0,0,0"/>
   <wangtile tileid="118" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="119" wangid="0,0,0,0,0,2,0,2"/>
   <wangtile tileid="149" wangid="0,2,0,0,0,0,0,0"/>
   <wangtile tileid="150" wangid="0,2,0,0,0,0,0,2"/>
   <wangtile tileid="151" wangid="0,0,0,0,0,0,0,2"/>
   <wangtile tileid="181" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="182" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="183" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="208" wangid="0,1,0,0,0,1,0,1"/>
   <wangtile tileid="209" wangid="0,1,0,1,0,0,0,1"/>
   <wangtile tileid="240" wangid="0,0,0,1,0,1,0,1"/>
   <wangtile tileid="241" wangid="0,1,0,1,0,1,0,0"/>
   <wangtile tileid="271" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="272" wangid="0,0,0,1,0,1,0,0"/>
   <wangtile tileid="273" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="298" wangid="0,3,0,0,0,3,0,3"/>
   <wangtile tileid="299" wangid="0,3,0,3,0,0,0,3"/>
   <wangtile tileid="303" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="304" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="305" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="310" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="330" wangid="0,0,0,3,0,3,0,3"/>
   <wangtile tileid="331" wangid="0,3,0,3,0,3,0,0"/>
   <wangtile tileid="335" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="336" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="337" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="361" wangid="0,0,0,3,0,0,0,0"/>
   <wangtile tileid="362" wangid="0,0,0,3,0,3,0,0"/>
   <wangtile tileid="363" wangid="0,0,0,0,0,3,0,0"/>
   <wangtile tileid="367" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="368" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="369" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="374" wangid="0,3,0,2,0,3,0,3"/>
   <wangtile tileid="375" wangid="0,3,0,3,0,2,0,3"/>
   <wangtile tileid="393" wangid="0,3,0,3,0,0,0,0"/>
   <wangtile tileid="394" wangid="0,3,0,3,0,3,0,3"/>
   <wangtile tileid="395" wangid="0,0,0,0,0,3,0,3"/>
   <wangtile tileid="406" wangid="0,2,0,3,0,3,0,3"/>
   <wangtile tileid="407" wangid="0,3,0,3,0,3,0,2"/>
   <wangtile tileid="425" wangid="0,3,0,0,0,0,0,0"/>
   <wangtile tileid="426" wangid="0,3,0,0,0,0,0,3"/>
   <wangtile tileid="427" wangid="0,0,0,0,0,0,0,3"/>
   <wangtile tileid="437" wangid="0,2,0,3,0,2,0,2"/>
   <wangtile tileid="438" wangid="0,2,0,3,0,3,0,2"/>
   <wangtile tileid="439" wangid="0,2,0,2,0,3,0,2"/>
   <wangtile tileid="457" wangid="0,3,0,3,0,3,0,3"/>
   <wangtile tileid="458" wangid="0,3,0,3,0,3,0,3"/>
   <wangtile tileid="459" wangid="0,3,0,3,0,3,0,3"/>
   <wangtile tileid="469" wangid="0,3,0,3,0,2,0,2"/>
   <wangtile tileid="470" wangid="0,3,0,3,0,3,0,3"/>
   <wangtile tileid="471" wangid="0,2,0,2,0,3,0,3"/>
   <wangtile tileid="501" wangid="0,3,0,2,0,2,0,2"/>
   <wangtile tileid="502" wangid="0,3,0,2,0,2,0,3"/>
   <wangtile tileid="503" wangid="0,2,0,2,0,2,0,3"/>
   <wangtile tileid="533" wangid="0,3,0,3,0,3,0,3"/>
   <wangtile tileid="534" wangid="0,3,0,3,0,3,0,3"/>
   <wangtile tileid="830" wangid="0,5,0,5,0,4,0,5"/>
   <wangtile tileid="831" wangid="0,5,0,5,0,5,0,5"/>
   <wangtile tileid="862" wangid="0,4,0,4,0,4,0,4"/>
   <wangtile tileid="863" wangid="0,5,0,4,0,4,0,5"/>
   <wangtile tileid="1011" wangid="0,5,0,5,0,5,0,4"/>
   <wangtile tileid="1012" wangid="0,4,0,5,0,5,0,4"/>
   <wangtile tileid="1013" wangid="0,4,0,5,0,5,0,5"/>
   <wangtile tileid="1014" wangid="0,4,0,4,0,5,0,5"/>
   <wangtile tileid="1015" wangid="0,5,0,4,0,5,0,5"/>
   <wangtile tileid="1016" wangid="0,5,0,5,0,4,0,4"/>
   <wangtile tileid="1035" wangid="0,3,0,3,0,3,0,3"/>
   <wangtile tileid="1036" wangid="0,6,0,3,0,6,0,6"/>
   <wangtile tileid="1037" wangid="0,6,0,6,0,3,0,6"/>
   <wangtile tileid="1038" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="1039" wangid="0,6,0,2,0,6,0,6"/>
   <wangtile tileid="1040" wangid="0,6,0,6,0,2,0,6"/>
   <wangtile tileid="1044" wangid="0,5,0,4,0,2,0,2"/>
   <wangtile tileid="1045" wangid="0,2,0,2,0,4,0,5"/>
   <wangtile tileid="1067" wangid="0,3,0,3,0,3,0,3"/>
   <wangtile tileid="1068" wangid="0,3,0,6,0,6,0,6"/>
   <wangtile tileid="1069" wangid="0,6,0,6,0,6,0,3"/>
   <wangtile tileid="1070" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="1071" wangid="0,2,0,6,0,6,0,6"/>
   <wangtile tileid="1072" wangid="0,6,0,6,0,6,0,2"/>
   <wangtile tileid="1074" wangid="0,2,0,5,0,2,0,2"/>
   <wangtile tileid="1075" wangid="0,2,0,2,0,5,0,2"/>
   <wangtile tileid="1076" wangid="0,4,0,4,0,4,0,4"/>
   <wangtile tileid="1077" wangid="0,2,0,4,0,2,0,2"/>
   <wangtile tileid="1078" wangid="0,2,0,2,0,4,0,2"/>
   <wangtile tileid="1080" wangid="0,4,0,5,0,4,0,4"/>
   <wangtile tileid="1081" wangid="0,4,0,4,0,5,0,4"/>
   <wangtile tileid="1099" wangid="0,3,0,6,0,3,0,3"/>
   <wangtile tileid="1100" wangid="0,3,0,6,0,6,0,3"/>
   <wangtile tileid="1101" wangid="0,3,0,3,0,6,0,3"/>
   <wangtile tileid="1102" wangid="0,2,0,6,0,2,0,2"/>
   <wangtile tileid="1103" wangid="0,2,0,6,0,6,0,2"/>
   <wangtile tileid="1104" wangid="0,2,0,2,0,6,0,2"/>
   <wangtile tileid="1106" wangid="0,5,0,2,0,2,0,2"/>
   <wangtile tileid="1107" wangid="0,2,0,2,0,2,0,5"/>
   <wangtile tileid="1108" wangid="0,4,0,4,0,4,0,4"/>
   <wangtile tileid="1109" wangid="0,4,0,2,0,2,0,2"/>
   <wangtile tileid="1110" wangid="0,2,0,2,0,2,0,4"/>
   <wangtile tileid="1112" wangid="0,5,0,4,0,4,0,4"/>
   <wangtile tileid="1113" wangid="0,4,0,4,0,4,0,5"/>
   <wangtile tileid="1131" wangid="0,6,0,6,0,3,0,3"/>
   <wangtile tileid="1132" wangid="0,6,0,6,0,6,0,6"/>
   <wangtile tileid="1133" wangid="0,3,0,3,0,6,0,6"/>
   <wangtile tileid="1134" wangid="0,6,0,6,0,2,0,2"/>
   <wangtile tileid="1135" wangid="0,6,0,6,0,6,0,6"/>
   <wangtile tileid="1136" wangid="0,2,0,2,0,6,0,6"/>
   <wangtile tileid="1137" wangid="0,5,0,2,0,5,0,5"/>
   <wangtile tileid="1138" wangid="0,5,0,2,0,2,0,5"/>
   <wangtile tileid="1139" wangid="0,5,0,5,0,2,0,5"/>
   <wangtile tileid="1140" wangid="0,4,0,2,0,4,0,4"/>
   <wangtile tileid="1141" wangid="0,4,0,2,0,2,0,4"/>
   <wangtile tileid="1142" wangid="0,4,0,4,0,2,0,4"/>
   <wangtile tileid="1163" wangid="0,6,0,3,0,3,0,3"/>
   <wangtile tileid="1164" wangid="0,6,0,3,0,3,0,6"/>
   <wangtile tileid="1165" wangid="0,3,0,3,0,3,0,6"/>
   <wangtile tileid="1166" wangid="0,6,0,2,0,2,0,2"/>
   <wangtile tileid="1167" wangid="0,6,0,2,0,2,0,6"/>
   <wangtile tileid="1168" wangid="0,2,0,2,0,2,0,6"/>
   <wangtile tileid="1169" wangid="0,2,0,2,0,5,0,5"/>
   <wangtile tileid="1170" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="1171" wangid="0,5,0,5,0,2,0,2"/>
   <wangtile tileid="1172" wangid="0,2,0,2,0,4,0,4"/>
   <wangtile tileid="1173" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="1174" wangid="0,4,0,4,0,2,0,2"/>
   <wangtile tileid="1195" wangid="0,6,0,6,0,6,0,6"/>
   <wangtile tileid="1196" wangid="0,6,0,6,0,6,0,6"/>
   <wangtile tileid="1197" wangid="0,6,0,6,0,6,0,6"/>
   <wangtile tileid="1199" wangid="0,2,0,6,0,3,0,3"/>
   <wangtile tileid="1200" wangid="0,3,0,3,0,6,0,2"/>
   <wangtile tileid="1201" wangid="0,2,0,5,0,5,0,5"/>
   <wangtile tileid="1202" wangid="0,2,0,5,0,5,0,2"/>
   <wangtile tileid="1203" wangid="0,5,0,5,0,5,0,2"/>
   <wangtile tileid="1204" wangid="0,2,0,4,0,4,0,4"/>
   <wangtile tileid="1205" wangid="0,2,0,4,0,4,0,2"/>
   <wangtile tileid="1206" wangid="0,4,0,4,0,4,0,2"/>
   <wangtile tileid="1231" wangid="0,6,0,2,0,3,0,3"/>
   <wangtile tileid="1232" wangid="0,3,0,3,0,2,0,6"/>
   <wangtile tileid="1236" wangid="0,5,0,5,0,5,0,5"/>
   <wangtile tileid="1237" wangid="0,5,0,5,0,5,0,5"/>
   <wangtile tileid="1238" wangid="0,5,0,5,0,5,0,5"/>
   <wangtile tileid="1347" wangid="0,7,0,0,0,7,0,7"/>
   <wangtile tileid="1348" wangid="0,7,0,7,0,0,0,7"/>
   <wangtile tileid="1379" wangid="0,0,0,7,0,7,0,7"/>
   <wangtile tileid="1380" wangid="0,7,0,7,0,7,0,0"/>
   <wangtile tileid="1410" wangid="0,0,0,7,0,0,0,0"/>
   <wangtile tileid="1411" wangid="0,0,0,7,0,7,0,0"/>
   <wangtile tileid="1412" wangid="0,0,0,0,0,7,0,0"/>
   <wangtile tileid="1442" wangid="0,7,0,7,0,0,0,0"/>
   <wangtile tileid="1443" wangid="0,7,0,7,0,7,0,7"/>
   <wangtile tileid="1444" wangid="0,0,0,0,0,7,0,7"/>
   <wangtile tileid="1474" wangid="0,7,0,0,0,0,0,0"/>
   <wangtile tileid="1475" wangid="0,7,0,0,0,0,0,7"/>
   <wangtile tileid="1476" wangid="0,0,0,0,0,0,0,7"/>
  </wangset>
 </wangsets>
</tileset>
