<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="maze_tiles" tilewidth="32" tileheight="32" tilecount="2" columns="1">
 <image source="maze_tiles.png" width="32" height="64"/>
 <tile id="0">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="32"/>
  </objectgroup>
 </tile>
</tileset>
