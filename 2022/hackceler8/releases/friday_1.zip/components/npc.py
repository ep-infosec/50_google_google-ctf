# Copyright 2022 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Optional

from gametree import *
import components.grate_door
import settings
import persistent_state
import keys
import gametree
if settings.environ == 'client':
    from menus import chat


class QuizNPC(serialize.SerializableObject):
    INTRODUCTION = "I'm Quirell the Quizzer. Answer my questions for a flag."
    QUESTIONS = [
        "What gets wetter as it dries?",
        "What is full of holes yet full of water?",
        "Heads or tails?",
    ]
    ANSWERS = ["towel", "sponge"]
    REPLIES_GOOD = [
        "Yup, that's right.",
        "Correct again. Just one more to go.",
        "What?! Incredible!"
    ]
    REPLY_NO_JOKING = "Stop kidding around."
    REPLY_BAD = "Try again. "
    REPLY_OTHER = "Nope, it flipped the other way. Try again: heads or tails?"
    REPLY_SOLVED = "You passed all three tests, so I guess I'll open the door for you."
    REPLY_FINAL = "Nice work."

    def __init__(self, flag_door):
        self.history = []
        for comp in flag_door.components:
            if isinstance(comp, components.grate_door.GrateDoor):
                self.flag_door = comp
        pass

    def on_open(self):
        if settings.environ == "client":
            environ.client.pending_chat = chat.ChatMenu(environ.game, "Hello!")
        self.history = []

    def on_query(self, txt):
        if self.INTRODUCTION not in self.history:
            reply = self.INTRODUCTION
        elif self.REPLY_SOLVED in self.history:
            reply = self.REPLY_FINAL
        else:
            max_question_good = -1
            for i, q in enumerate(self.REPLIES_GOOD):
                if q in self.history:
                    max_question_good = i
            if max_question_good == len(self.QUESTIONS) - 1:
                reply = self.REPLY_SOLVED
                self.flag_door.locked = False
            elif self.QUESTIONS[max_question_good + 1] not in self.history:
                reply = self.QUESTIONS[max_question_good + 1]
            else:
                # Player now answers the question.
                if max_question_good != len(self.QUESTIONS) - 2:
                    if txt == self.ANSWERS[max_question_good + 1]:
                        reply = self.REPLIES_GOOD[max_question_good + 1]
                    else:
                        reply = self.REPLY_BAD
                else:
                    if txt not in ["heads", "tails"]:
                        reply = self.REPLY_NO_JOKING
                    else:
                        reply = self.REPLY_OTHER


        self.history.append(txt)
        self.history.append(reply)

        if settings.environ == "client":
            environ.client.pending_chat = chat.ChatMenu(environ.game, reply)


class NPC(Component):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.initialized = False
        self.npc = None

    def update_animation(self, frameset):
        if frameset != self.entity.frameset:
            self.entity.frameset = frameset

    def tick(self):
        # Cannot do this in __init__, the fields are not set there yet.
        if not self.initialized:
            self.initialized = True
            if self.name == "npc_quiz":
                self.npc = QuizNPC(self.flag_door)
            else:
                raise Exception("Unknown NPC")
        if self.npc is not None and hasattr(self.npc, "tick"):
            self.npc.tick()

    def on_activation(self):
        environ.game.now_talking_to = self.npc
        environ.game.now_talking_to.on_open()

    def on_collision_enter(self, other):
        pass

    def while_colliding(self, other):
        pass

    def on_collision_exit(self, other):
        pass

    def duplicate(self, new_entity):
        ret = self.__class__()
        return ret
