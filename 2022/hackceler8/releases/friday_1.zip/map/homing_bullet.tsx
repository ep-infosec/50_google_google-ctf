<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="homing_bullet" tilewidth="32" tileheight="32" tilecount="80" columns="20">
 <image source="homing_bullet.png" width="640" height="128"/>
 <tile id="0">
  <properties>
   <property name="frameset" value="homing"/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="1" y="16">
    <polygon points="0,0 2,-7 10,-14 12,-15 17,-15 23,-13 27,-9 29,-4 30,-2 30,4 28,8 22,13 18,15 13,15 8,13 4,9 1,4"/>
   </object>
  </objectgroup>
  <animation>
   <frame tileid="0" duration="30"/>
   <frame tileid="1" duration="30"/>
   <frame tileid="2" duration="30"/>
   <frame tileid="3" duration="30"/>
   <frame tileid="4" duration="30"/>
   <frame tileid="5" duration="30"/>
   <frame tileid="6" duration="30"/>
   <frame tileid="7" duration="30"/>
   <frame tileid="8" duration="30"/>
   <frame tileid="9" duration="30"/>
   <frame tileid="10" duration="30"/>
   <frame tileid="11" duration="30"/>
   <frame tileid="12" duration="30"/>
   <frame tileid="32" duration="30"/>
   <frame tileid="31" duration="30"/>
   <frame tileid="30" duration="30"/>
   <frame tileid="29" duration="30"/>
   <frame tileid="28" duration="30"/>
   <frame tileid="27" duration="30"/>
   <frame tileid="26" duration="30"/>
   <frame tileid="25" duration="30"/>
   <frame tileid="24" duration="30"/>
   <frame tileid="23" duration="30"/>
   <frame tileid="22" duration="30"/>
   <frame tileid="21" duration="30"/>
   <frame tileid="20" duration="30"/>
  </animation>
 </tile>
 <tile id="13">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="32" height="4"/>
  </objectgroup>
 </tile>
 <tile id="60">
  <properties>
   <property name="frameset" value="exploding"/>
  </properties>
  <animation>
   <frame tileid="60" duration="15"/>
   <frame tileid="61" duration="15"/>
   <frame tileid="62" duration="15"/>
   <frame tileid="63" duration="15"/>
   <frame tileid="64" duration="15"/>
   <frame tileid="65" duration="15"/>
   <frame tileid="66" duration="15"/>
   <frame tileid="67" duration="15"/>
   <frame tileid="68" duration="15"/>
   <frame tileid="69" duration="15"/>
   <frame tileid="70" duration="15"/>
   <frame tileid="71" duration="15"/>
   <frame tileid="72" duration="15"/>
  </animation>
 </tile>
</tileset>
