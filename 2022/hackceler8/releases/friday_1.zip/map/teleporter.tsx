<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="teleporter" tilewidth="32" tileheight="32" tilecount="3" columns="3">
 <image source="teleporter.png" width="96" height="32"/>
 <tile id="0">
  <animation>
   <frame tileid="0" duration="200"/>
   <frame tileid="1" duration="200"/>
   <frame tileid="2" duration="200"/>
  </animation>
 </tile>
</tileset>
