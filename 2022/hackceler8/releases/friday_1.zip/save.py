# Copyright 2022 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import map_loader
import serialize
import validation
import serialization_pb2
import context_aware_serialization

class SaveBlob(serialize.SerializableObject):
    def __init__(self):
        self.game = None
        self.current_game = b""

def make_blob(game, map_name):
    blob = SaveBlob()
    blob.game = validation.server_state_binary_serialized(game)
    blob.current_game = map_name
    blob = validation.server_state_binary_serialized(blob)
    return blob

def load_blob(blob):
    blob_proto = serialization_pb2.SerializedPackage.FromString(blob)
    blob = serialize.Deserialize(blob_proto)

    base_map = map_loader.load_map(map_loader.list_maps()[blob.current_game])
    c = context_aware_serialization.Context(base_map.tmx_map)
    current_game_proto = serialization_pb2.SerializedPackage.FromString(blob.game)
    blob: SaveBlob = serialize.Deserialize(current_game_proto, context=c)

    return blob