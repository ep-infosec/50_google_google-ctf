# Copyright 2022 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Optional

from gametree import *
import components.grate_door
import settings
import persistent_state
import keys
import gametree
if settings.environ == 'client':
    from menus import chat

def ymd_to_weekday(y, m, d):
    if y <= 0:
        raise Exception("Non-positive year")
    y, y400 = y % 400, y // 400

    # There are 146097 days in 400-year leap cycle.
    counter = y400 * 146097.0
    i = 0
    while i < y:
        leap = (i % 400 == 0 or (i % 4 == 0 and i % 100 != 0))
        if leap:
            counter += 366
        else:
            counter += 365
        i += 1

    leap = (y % 400 == 0 or (y % 4 == 0 and y % 100 != 0))
    months = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    if leap:
        months[1] = 29
    i = 1
    while i < m:
        counter += months[i-1]
        i += 1
    counter += d-1
    counter += 6 # 2000-01-01 is Saturday
    return round(counter % 7, 0)

class WeekNPC(serialize.SerializableObject):
    def __init__(self, flag_door):
        for comp in flag_door.components:
            if isinstance(comp, components.grate_door.GrateDoor):
                self.flag_door = comp
        self.state = 0
        pass

    Q_WHO = "Who are you?"
    Q_WHAT = "What do you do for a living?"
    Q_FLAG = "Can you give me a flag?"
    OK_FLAG = "Oh, looks like I don't have an appointment today. I opened the door for you."
    EXCUSES = {
            1: "I'm teaching kids on Mondays",
            2: "Tuesdays I'm going to town to sell apples",
            3: "Wednesdays I'm weaving baskets",
            4: "On Thursdays, I'm helping at the mine",
            5: "Ah, Fridays I generally take time to notice the beauty of the world and write some poetry",
            6: "Saturdays I'm going to town to buy supplies for the next week",
            7: "Free.",
            0: "Free."
            }
    QUERIES = [Q_WHO, Q_WHAT, Q_FLAG]


    def on_open(self):
        if settings.environ == "client":
            environ.client.pending_chat = chat.ChatMenu(environ.game, "Hello!", ["Hello!"])
        self.state = -1

    def on_query(self, txt):
        reply = "..."
        answers = ["Ok..."]
        if self.state == -1:
            self.state = 0
            reply = "How can I help you?"
            answers = list(self.QUERIES)
        elif self.state == 0:
            self.state = -1
            if txt == self.Q_WHO:
                reply = "I'm Jack of all Trades!"
            elif txt == self.Q_WHAT:
                reply = "All kinds of stuff: teaching kids, trading, writing poetry..."
            elif txt == self.Q_FLAG:
                reply = "Well, I'd need to look at my schedule. Can you remind me what date it is?"
                answers = []
                self.state = 1
        elif self.state == 1:
            try:
                y,m,d = txt.split("-")
                y = int(y)
                m = int(m)
                d = int(d)
                weekday = ymd_to_weekday(y, m, d)
                reply = self.OK_FLAG
                if weekday in self.EXCUSES:
                    reply = "I'm taking time off on Sundays. Maybe another time..."
                    if weekday != 7 and weekday != 0:
                        reply = self.EXCUSES[weekday] + " so I'll be busy today. Try another time!"

                self.state = -1
                if reply == self.OK_FLAG:
                    self.flag_door.locked = False

            except Exception as e:
                print(e)
                reply = "Umm, are you from overseas? We use YYYY-MM-DD date format here."
                self.state = -1

        if settings.environ == "client":
            environ.client.pending_chat = chat.ChatMenu(environ.game, reply, answers)


class NPC(Component):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.initialized = False
        self.npc = None

    def update_animation(self, frameset):
        if frameset != self.entity.frameset:
            self.entity.frameset = frameset

    def tick(self):
        # Cannot do this in __init__, the fields are not set there yet.
        if not self.initialized:
            self.initialized = True
            if self.name == "npc_week":
                self.npc = WeekNPC(self.flag_door)
            else:
                raise Exception("Unknown NPC")
        if self.npc is not None and hasattr(self.npc, "tick"):
            self.npc.tick()

    def on_activation(self, caller):
        environ.game.now_talking_to = self.npc
        environ.game.now_talking_to.on_open()

    def on_collision_enter(self, other):
        pass

    def while_colliding(self, other):
        pass

    def on_collision_exit(self, other):
        pass

    def duplicate(self, new_entity):
        ret = self.__class__()
        return ret
