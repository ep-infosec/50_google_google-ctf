# Copyright 2022 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import persistent_state
from gametree import *
from components import collectable

class TeleporterItem(collectable.Collectable):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.stored_location = None

    def on_use(self):
        if self.stored_location is None:
            p = environ.game.player.transform.position
            self.stored_location = (int(p.x), int(p.y))
            self.inventory_text = "Teleport back"
        else:
            (x, y) = self.stored_location
            environ.game.player.transform.position.x = x
            environ.game.player.transform.position.y = y
            self.stored_location = None
            self.inventory_text = "Store pos"

        # Do not return item
        return False

