"""pytiled_parser version"""

__version__ = "2.0.1"
