<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="frog" tilewidth="32" tileheight="32" tilecount="11" columns="11">
 <image source="Free/Main Characters/Ninja Frog/Idle (32x32).png" width="352" height="32"/>
</tileset>
