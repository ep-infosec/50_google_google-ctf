<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="tileset" tilewidth="18" tileheight="18" tilecount="20" columns="5">
 <tileoffset x="0" y="1"/>
 <image source="../../images/hexmini.png" width="106" height="72"/>
</tileset>
