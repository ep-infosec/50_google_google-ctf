<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="tile_set_image" tilewidth="32" tileheight="32" spacing="1" margin="1" tilecount="48" columns="8">
 <transformations hflip="1" vflip="0" rotate="0" preferuntransformed="0"/>
 <image source="../../images/tmw_desert_spacing.png" width="265" height="199"/>
</tileset>
