class UnknownFormat(Exception):
    pass
