<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="white_square" tilewidth="32" tileheight="32" tilecount="1" columns="1">
 <image source="white_square.png" width="32" height="32"/>
 <tile id="0">
  <animation>
   <frame tileid="0" duration="60"/>
  </animation>
 </tile>
</tileset>
