<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="window-border" tilewidth="32" tileheight="32" tilecount="54" columns="3">
 <image source="window-border.png" width="96" height="576"/>
 <tile id="0">
  <animation>
   <frame tileid="0" duration="60"/>
  </animation>
 </tile>
 <tile id="1">
  <animation>
   <frame tileid="1" duration="60"/>
  </animation>
 </tile>
 <tile id="2">
  <animation>
   <frame tileid="2" duration="60"/>
  </animation>
 </tile>
 <tile id="3">
  <animation>
   <frame tileid="3" duration="60"/>
  </animation>
 </tile>
 <tile id="4">
  <animation>
   <frame tileid="4" duration="60"/>
  </animation>
 </tile>
 <tile id="5">
  <animation>
   <frame tileid="5" duration="60"/>
  </animation>
 </tile>
 <tile id="6">
  <animation>
   <frame tileid="6" duration="60"/>
  </animation>
 </tile>
 <tile id="7">
  <animation>
   <frame tileid="7" duration="60"/>
  </animation>
 </tile>
 <tile id="8">
  <animation>
   <frame tileid="8" duration="60"/>
  </animation>
 </tile>
 <tile id="9">
  <animation>
   <frame tileid="9" duration="60"/>
  </animation>
 </tile>
 <tile id="10">
  <animation>
   <frame tileid="10" duration="60"/>
  </animation>
 </tile>
 <tile id="11">
  <animation>
   <frame tileid="11" duration="60"/>
  </animation>
 </tile>
 <tile id="12">
  <animation>
   <frame tileid="12" duration="60"/>
  </animation>
 </tile>
 <tile id="13">
  <animation>
   <frame tileid="13" duration="60"/>
  </animation>
 </tile>
 <tile id="14">
  <animation>
   <frame tileid="14" duration="60"/>
  </animation>
 </tile>
 <tile id="15">
  <animation>
   <frame tileid="15" duration="60"/>
  </animation>
 </tile>
 <tile id="16">
  <animation>
   <frame tileid="16" duration="60"/>
  </animation>
 </tile>
 <tile id="17">
  <animation>
   <frame tileid="17" duration="60"/>
  </animation>
 </tile>
 <tile id="18">
  <animation>
   <frame tileid="18" duration="60"/>
  </animation>
 </tile>
 <tile id="19">
  <animation>
   <frame tileid="19" duration="60"/>
  </animation>
 </tile>
 <tile id="20">
  <animation>
   <frame tileid="20" duration="60"/>
  </animation>
 </tile>
 <tile id="21">
  <animation>
   <frame tileid="21" duration="60"/>
  </animation>
 </tile>
 <tile id="22">
  <animation>
   <frame tileid="22" duration="60"/>
  </animation>
 </tile>
 <tile id="23">
  <animation>
   <frame tileid="23" duration="60"/>
  </animation>
 </tile>
 <tile id="24">
  <animation>
   <frame tileid="24" duration="60"/>
  </animation>
 </tile>
 <tile id="25">
  <animation>
   <frame tileid="25" duration="60"/>
  </animation>
 </tile>
 <tile id="26">
  <animation>
   <frame tileid="26" duration="60"/>
  </animation>
 </tile>
 <tile id="27">
  <animation>
   <frame tileid="27" duration="60"/>
  </animation>
 </tile>
 <tile id="28">
  <animation>
   <frame tileid="28" duration="60"/>
  </animation>
 </tile>
 <tile id="29">
  <animation>
   <frame tileid="29" duration="60"/>
  </animation>
 </tile>
 <tile id="30">
  <animation>
   <frame tileid="30" duration="60"/>
  </animation>
 </tile>
 <tile id="31">
  <animation>
   <frame tileid="31" duration="60"/>
  </animation>
 </tile>
 <tile id="32">
  <animation>
   <frame tileid="32" duration="60"/>
  </animation>
 </tile>
 <tile id="33">
  <animation>
   <frame tileid="33" duration="60"/>
  </animation>
 </tile>
 <tile id="34">
  <animation>
   <frame tileid="34" duration="60"/>
  </animation>
 </tile>
 <tile id="35">
  <animation>
   <frame tileid="35" duration="60"/>
  </animation>
 </tile>
 <tile id="36">
  <animation>
   <frame tileid="36" duration="60"/>
  </animation>
 </tile>
 <tile id="37">
  <animation>
   <frame tileid="37" duration="60"/>
  </animation>
 </tile>
 <tile id="38">
  <animation>
   <frame tileid="38" duration="60"/>
  </animation>
 </tile>
 <tile id="39">
  <animation>
   <frame tileid="39" duration="60"/>
  </animation>
 </tile>
 <tile id="40">
  <animation>
   <frame tileid="40" duration="60"/>
  </animation>
 </tile>
 <tile id="41">
  <animation>
   <frame tileid="41" duration="60"/>
  </animation>
 </tile>
 <tile id="42">
  <animation>
   <frame tileid="42" duration="60"/>
  </animation>
 </tile>
 <tile id="43">
  <animation>
   <frame tileid="43" duration="60"/>
  </animation>
 </tile>
 <tile id="44">
  <animation>
   <frame tileid="44" duration="60"/>
  </animation>
 </tile>
 <tile id="45">
  <animation>
   <frame tileid="45" duration="60"/>
  </animation>
 </tile>
 <tile id="46">
  <animation>
   <frame tileid="46" duration="60"/>
  </animation>
 </tile>
 <tile id="47">
  <animation>
   <frame tileid="47" duration="60"/>
  </animation>
 </tile>
 <tile id="48">
  <animation>
   <frame tileid="48" duration="60"/>
  </animation>
 </tile>
 <tile id="49">
  <animation>
   <frame tileid="49" duration="60"/>
  </animation>
 </tile>
 <tile id="50">
  <animation>
   <frame tileid="50" duration="60"/>
  </animation>
 </tile>
 <tile id="51">
  <animation>
   <frame tileid="51" duration="60"/>
  </animation>
 </tile>
 <tile id="52">
  <animation>
   <frame tileid="52" duration="60"/>
  </animation>
 </tile>
 <tile id="53">
  <animation>
   <frame tileid="53" duration="60"/>
  </animation>
 </tile>
</tileset>
