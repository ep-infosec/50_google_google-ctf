<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="palms" tilewidth="32" tileheight="32" tilecount="204" columns="12">
 <image source="palms.png" width="384" height="544"/>
 <tile id="49">
  <objectgroup draworder="index" id="2">
   <object id="1" x="9" y="0" width="14" height="39"/>
  </objectgroup>
 </tile>
</tileset>
